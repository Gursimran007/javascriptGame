var numbersArray = new Array;
var count = 0 , id1 , id2 , value1 , value2 , winnerCounter = 0;
var startTime , endTime;
$(document).ready(function (){
    gameInitializer.init();
    StopWatch.prototype.Start = function()
    {
        this.StartMilliseconds = new Date().getTime();
    }
});
var gameInitializer = {
    init :function(){
        this.startTime();
        for(var i=0 ; i < 4 ; i++)
            this.generateRandomNumbers();
        numbersArray.push(0);
        var shuffledArray  =this.shuffleArray(numbersArray);
        console.log(shuffledArray)
        this.PassingValuesToButtons(shuffledArray);
        $("#restart").click(function(){
            location.reload();
        })
        $(".buttonGrid").click(function(){
            count++;
            var id = $(this).attr('id');
            var x = document.getElementById(id);
            // $("#"+id).css({'background-color':'purple'});
            $("#"+id).addClass("purple");
            $("#"+id).html(x.value);
            if(count == 1){
                oldTime = new Date(); 
                oldHr = oldTime.getHours();
                oldMin = oldTime.getMinutes();
                oldSec = oldTime.getSeconds();
                id1 = document.getElementById(id);
                value1 = document.getElementById(id).value;
            }
            if(count == 2){
                id2 = document.getElementById(id);
                value2 = document.getElementById(id).value;
                count = 0;
                gameInitializer.checkNumbers(id1 , id2 , value1 , value2);
            }
        })
    },
    generateRandomNumbers: function(){
        var x = Math.floor((Math.random() * 100) + 1);
        if(numbersArray.includes(x)){
            this.generateRandomNumbers();
        }
        for(var i = 0 ; i < 2 ; i++){
            numbersArray.push(x);
        }
    },
    shuffleArray : function(array){
        var currentIndex = array.length, temporaryValue, randomIndex;
        while (currentIndex != 0) {
          randomIndex = Math.floor(Math.random() * currentIndex);
          currentIndex -= 1;
          temporaryValue = array[currentIndex];
          array[currentIndex] = array[randomIndex];
          array[randomIndex] = temporaryValue;
        }
        return array;
    },
    startTime : function()
    {
        startTime = new Date();
    },
    endTime: function(){
        endTime = new Date();
        var timeDiff = endTime - startTime;
        timeDiff /= 1000;
        var seconds = Math.round(timeDiff);
        return seconds;
    },
    PassingValuesToButtons: function(array){
        for(var i  = 1 ; i<=array.length ; i++){
            $("#button"+i).prop('value',array[i-1]);
        }
    },
    checkNumbers: function(id1 , id2 , value1 , value2){
        if(value1 != value2){
            setTimeout(function(){
                $(id1).removeClass("purple").empty();
                $(id2).removeClass("purple").empty();
            },500);
        }
        if(id1.value == id2.value){
            $(id1).addClass("purple").attr('disabled','disabled');
            $(id2).addClass("purple").attr('disabled','disabled');
            var time = gameInitializer.endTime();
            winnerCounter++;
            if(winnerCounter == 4){
                setTimeout(function(){
                    // var time = hr+"hr"+":"+min+"mins"+":"+sec+"secs";
                    window.confirm("you won time taken by you is "+ time+" seconds"+" click restart to play again");
                },200); 
            }
        }
    }
}